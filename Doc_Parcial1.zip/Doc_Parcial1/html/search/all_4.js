var searchData=
[
  ['lower_5flevel_5fdevices_5fcount_0',['lower_level_devices_count',['../struct_header.html#a79180d42fd0f0c2d3a12bb915edd88ac',1,'Header']]]
];
