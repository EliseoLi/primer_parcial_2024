var searchData=
[
  ['id_0',['ID',['../struct_header.html#ac07074d4552c1071b995417b4279d472',1,'Header']]],
  ['info_1',['info',['../struct_header.html#a442314096e857e0562374a9035262aa0',1,'Header']]]
];
