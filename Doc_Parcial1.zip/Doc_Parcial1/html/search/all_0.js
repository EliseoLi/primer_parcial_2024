var searchData=
[
  ['device_5ftype_0',['device_type',['../struct_header.html#a1d64f59e7236476698ec343857654468',1,'Header']]]
];
